<?php include_once('header.php');?>
<title>Employee Details</title>
</head>

<body>
</body>
<?php include_once('footer.php'); ?>