<?php

define('HOST','localhost');
define('USER','kristabi_3760usr');
define('PASSWORD','LzP5Z#6pAB,=');
define('DB_NAME','kristabi_dgm3760play');




?>