	<?php if(!isset($_COOKIE['username'])){ ?>
<nav>
	<ul>
		<li><a href="index.php">Home</a></li>
	</ul>
</nav>

<div class="log">
	<a href="login.php">Login</a>
</div>
<?php } 

else{ ?>

<nav>
	<ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="add.php">Add</a></li>
		<li><a href="delete.php">Delete</a></li>
		
		
	</ul>
</nav>


<div class="log">
	<a href="logout.php">Logout</a>
</div>

<?php }
	?>